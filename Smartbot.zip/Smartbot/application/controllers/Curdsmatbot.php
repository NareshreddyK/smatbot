<?php
defined('BASEPATH') OR exit('No direct script access allowed');
//use chriskacerguis\RestServer\RestController;

class Curdsmatbot extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct()
    {
        // Construct the parent class
        parent::__construct();
		$this->load->database();
		$this->load->model('Crudsmatmodel');
    }

	public function index()
	{
		$this->load->view('welcome_message');
	}

	public function createContact()
	{

		$data['first_name']=$this->input->post('first_name');
		$data['last_name']=$this->input->post('last_name');
		$data['email']=$this->input->post('email');
		$data['mobile_number']=$this->input->post('mobile_number');
		$data['data_store']=$this->input->post('data_store');

		//echo print_r($data, true); exit();
		$response=$this->Crudsmatmodel->saverecords($data);
		if($response==true){
		        echo "Records Saved Successfully";
		}
		else{
				echo "Insert error !";
		}
	}

	public function getContact()
	{		
		$contact_id = $this->input->post('contact_id');
		
	    $result = $this->Crudsmatmodel->display_records($contact_id);
	    echo print_r($result[0], true); 
	   // return $result[0];
	    //$this->load->view('display_records',$result);
	}

	public function updateContact()
	{
		$id=$this->input->post('contact_id');
		$data = $this->Crudsmatmodel->displayrecordsById($id);
		// echo print_r($data[0]->idcontacts, true); exit();
		//$this->load->view('update_records',$result);
	
		if(!empty($data[0]->idcontacts))
		{
			//$first_name=$this->input->post('first_name');
			//$last_name=$this->input->post('last_name');
			$email=$this->input->post('email');
			$mobile=$this->input->post('mobile_number');
			$update = $this->Crudsmatmodel->update_records($email,$mobile,$id);
			if($update == 1)
			{
				echo "Date updated successfully !";
			}else
			{
				echo "Date updated Error !";
			}
			
		}
	}

	public function deleteContact()
	{
	  $id=$this->input->post('contact_id');
	  $response=$this->Crudsmatmodel->deleterecords($id);
	  if($response==true){
	    echo "Data deleted successfully !";
		}
	  else{
	    echo "Error !";
	  }
	}

	public function searchContact()
	{		
		$name = $this->input->post('first_name');
		
	    $result = $this->Crudsmatmodel->display_recordsName($name);
	   
	    echo print_r($result, true);
	    //$this->load->view('display_records',$result);
	}
}
