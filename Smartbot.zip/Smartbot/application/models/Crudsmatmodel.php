<?php
class Crudsmatmodel extends CI_Model 
{
	
	public function saverecords($data)
	{
        $this->db->insert('contacts',$data);
        return true;
	}

	public function display_records($id)
	{
	    $query=$this->db->query("Select * from contacts where idcontacts = '".$id."'");
	    return $query->result();
	}

	public function displayrecordsById($id)
	{
		$query=$this->db->query("Select * from contacts where idcontacts = '".$id."'");
		return $query->result();
	}
	
	public function update_records($email, $mobile, $id)
	{ 

	$query=$this->db->query("update contacts SET email='".$email."', mobile_number='".$mobile."' where idcontacts = '".$id."'");
	return $query;
	}

	public function deleterecords($id)
	{
	    $this->db->where("idcontacts", $id);
	    $this->db->delete("contacts");
	    return true;
	}
	
	public function display_recordsName($name)
	{
	    $query=$this->db->query("Select * from contacts where first_name like '".$name."%'");
	    return $query->result_array();
	}
}